# Wiki Api

>Language »» Farsi

## Example

``` 
import WikiApi

gpt = WikiApi.Gpt

info WikiApi.Info
```
<br><br><br>
<p align="center">
<a herf="https://wiki-api.ir/">WebSite</a>
-
<a herf="https://github.com/aliraeesi385/WikiApi">GitHub</a>
-
<a herrf="https://t.me/wiki_api">Telegram</a>
</p>