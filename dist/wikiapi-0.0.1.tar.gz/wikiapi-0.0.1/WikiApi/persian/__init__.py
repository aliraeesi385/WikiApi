from .horoscope import Horoscope

class Persian(
    Horoscope
):
    pass