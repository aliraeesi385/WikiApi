from .jok4 import Jok4
from .readyanswer import ReadyAnswer

class Entertainment(
    Jok4,
    ReadyAnswer
):
    pass